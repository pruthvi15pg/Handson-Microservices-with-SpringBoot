package com.ms.userpg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserpgApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserpgApplication.class, args);
	}

}

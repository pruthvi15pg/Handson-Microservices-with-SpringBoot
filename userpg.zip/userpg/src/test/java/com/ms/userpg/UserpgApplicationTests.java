package com.ms.userpg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserpgApplicationTests {

	@Test
	void contextLoads() {
	}

}
